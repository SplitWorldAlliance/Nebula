# Nova RPG Management System

Anodyne Production's next-generation RPG management system combines popular features from the SIMM Management System as well as new features like internationalization, developer enhancements, commenting on entries, dynamic forms, multiple characters per player, and much more to make Nova the premier web-based solution for managing your RPG game.

## Current Version

2.4.10

## Bug Tracker

Have a bug? Please create an issue here on GitHub!

https://github.com/anodyne/nova/issues