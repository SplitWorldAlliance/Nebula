<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

require MODPATH.'core/config/nova_mimes.php';
