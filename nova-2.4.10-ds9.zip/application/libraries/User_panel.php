<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

require_once MODPATH.'core/libraries/Nova_user_panel.php';

class User_panel extends Nova_user_panel {}
