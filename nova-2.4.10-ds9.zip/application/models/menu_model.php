<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

require_once MODPATH.'core/models/nova_menu_model.php';

class Menu_model extends Nova_menu_model {

	public function __construct()
	{
		parent::__construct();
	}
	/**
	 * Put your own methods below this...
	 */
}
